﻿using Microsoft.EntityFrameworkCore;
using SampleMVCApplication.Models;
using SampleMVCApplication.Data;
using SampleMVCApplication.Controllers;
using Microsoft.AspNetCore.Http.HttpResults;

namespace SampleMVCApplication.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly BookDBContext _bookDBContext;
        private readonly ILogger<BookController> _logger;

        public BookRepository(BookDBContext bookDBContext, ILogger<BookController> logger)
        {
            _bookDBContext = bookDBContext;
            _logger = logger;
        }

        public async Task<IEnumerable<Books>> FetchBooksAuthorTitleSP()
        {
            try
            {
                var books = await _bookDBContext.Books.FromSqlRaw("EXEC FetchSortedBy_AuthorTitless").ToListAsync();
                return books;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while FetchBooksAuthorTitleSP");
                throw new InvalidOperationException("Error in FetchBooksAuthorTitleSP");
            }

        }

        public async Task<IEnumerable<Books>> FetchBooksPublisherAuthorTitleSP()
        {
            try
            {
                var books = await _bookDBContext.Books.FromSqlRaw("EXEC FetechSortedBy_PublisherAuthorTitle").ToListAsync();

                return books;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, "An error occurred while FetchBooksPublisherAuthorTitleSP");
                throw new InvalidOperationException("Error in FetchBooksPublisherAuthorTitleSP");
            }

        }

        public async Task<IEnumerable<Books>> FetchBooksAuthorTitle()
        {
            try
            {
                return await _bookDBContext.Books
    .OrderBy(b => b.AuthorLastName)
    .ThenBy(b => b.AuthorFirstName)
    .ThenBy(b => b.Title)
    .ToListAsync();
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, "An error occurred while FetchBooksAuthorTitle");
                throw new InvalidOperationException("Error in FetchBooksAuthorTitle");
            }

        }

        public async Task<IEnumerable<Books>> FetchBooksPublisherAuthorTitle()
        {
            try
            {
                return await _bookDBContext.Books
                    .OrderBy(b => b.Publisher)
    .ThenBy(b => b.AuthorLastName)
    .ThenBy(b => b.AuthorFirstName)
    .ThenBy(b => b.Title)
    .ToListAsync();
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, "An error occurred while FetchBooksPublisherAuthorTitle");
                throw new InvalidOperationException("Error in FetchBooksPublisherAuthorTitle");
            }

        }

        public async Task<decimal> FetchTotalPrice()
        {
            try
            {
                return await _bookDBContext.Books.SumAsync(s => s.Price);
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, "An error occurred while FetchTotalPrice");
                throw new InvalidOperationException("Error in FetchTotalPrice");
            }


        }
    }
}
